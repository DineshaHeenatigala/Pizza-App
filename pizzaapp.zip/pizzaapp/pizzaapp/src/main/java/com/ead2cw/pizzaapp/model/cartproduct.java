package com.ead2cw.pizzaapp.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.util.List;

@Entity
public class cartproduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    private List<String> proList;

    private Integer userId;

    public cartproduct(){
        super();
    }

    public cartproduct(int orderId, Integer userId){
        this.orderId = orderId;
        this.userId = userId;
    }



    public Integer getUserId(){
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}
