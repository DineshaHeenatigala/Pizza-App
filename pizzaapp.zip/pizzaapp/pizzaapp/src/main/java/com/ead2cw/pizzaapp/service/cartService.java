package com.ead2cw.pizzaapp.service;
import com.ead2cw.pizzaapp.model.cartproduct;
import com.ead2cw.pizzaapp.model.cart;
import com.ead2cw.pizzaapp.repository.pizzaRepository;
import com.ead2cw.pizzaapp.repository.cartrepositary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class cartService implements cartinterface {

@Autowired
    private cartrepositary cartrepositary;
@Autowired
    private pizzaRepository pizzaRepository;

   @Override
    public String savecartproduct(cartproduct cartproduct){
       cartrepositary.save(cartproduct);

        return "cart added!";
   }

    @Override
    public List<cartproduct> getAll(){
       return cartrepositary.findAll();
    }

    @Override
    public void clearCart() {

    }

    @Override
    public void deleteProduct(int id){

       cartrepositary.deleteById(id);


    }


}
