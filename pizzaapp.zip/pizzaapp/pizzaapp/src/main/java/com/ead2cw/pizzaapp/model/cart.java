package com.ead2cw.pizzaapp.model;

import java.util.ArrayList;
import java.util.List;

public class cart {

    private List<Integer> proList = new ArrayList<>();

    public cart(){
        super();
    }

    public List<Integer> getProList(){
        return proList; }

    public void setProList(List<Integer> proList) {
        this.proList = proList;
    }

    public String addToCart(int id){
        proList.add(id);
       return "product addded sucefully!";
    }

    public List<Integer> readCart(){
        return proList;
    }

    public void clear(){

        proList.clear();
    }


    public String deleteProduct(int id) {
        proList.remove(id);

        return "deleted";
    }
}
