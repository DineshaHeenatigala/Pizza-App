package com.ead2cw.pizzaapp.service;

import com.ead2cw.pizzaapp.model.User;

public interface Userinterface {

    public String saveUser(User user);

    public String login(String username, String password);
}
