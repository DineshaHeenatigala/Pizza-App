  #### 1.How to create this App

To create this project I have used **spring Framework** **,** **JPA Framework** and **HTML/CSS** to create login form.

   - First you should create a Maven project  with using perticuler dependencies inside the springboot.
   
  - This application runs JDK17 or higer versions. Then make sure to install latest version of JDK.

  - And you should create a  mysql db inside to save the data.(To create a database, make sure download and install a server like xampp or wampp.)

   - Then you can create your project using MVC architecture.

   #### 2.How to use this App

   - Maven application start running you can access it by typing localhost:8080 on the address of your browser.

   - Then you can log in to the system entering user name as **"dinesha"** and password as **"123"**.

   - Make sure you have access to the internet with stable connection.

   - Here you can add , delete , findall products using **pizzaController**.

   - And you can add products to the cart and create and delete a cart using **Cartcontroller**.

   - cart class is manage only cart functionality. It doesn't  save the details include about products in the cart to the database. cart functions are handle only run time.