package com.ead2cw.pizzaapp.controller;

import com.ead2cw.pizzaapp.model.pizza;

import com.ead2cw.pizzaapp.service.pizzaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController

@RequestMapping("/pizza")
public class pizzaController {
   public String message;

    @Autowired
    private pizzaService pizzaService ;

    @PostMapping("/add")
    public String add(@RequestBody pizza pizza){
        pizzaService.savepizzaUser(pizza);
        return "New user is added";
    }
    @GetMapping("/getAll")
    public List<pizza> getAllUsers(){
        return pizzaService.getAllUsers();
    }

    @PostMapping("/deleteById")
    public void deleteById(int id){

        pizzaService.deleteProduct(id);
        message = "product delete sucessfully!";
    }
}
