package com.ead2cw.pizzaapp.service;

import com.ead2cw.pizzaapp.model.cartproduct;

import java.util.List;

public interface cartinterface {
  public String savecartproduct(cartproduct cartproduct);

  public List<cartproduct> getAll();

  public void clearCart();

  public void deleteProduct(int id);

}
