package com.ead2cw.pizzaapp.repository;

import com.ead2cw.pizzaapp.model.cartproduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository

public interface cartrepositary extends JpaRepository<cartproduct,Integer> {



}
