package com.ead2cw.pizzaapp.service;

import com.ead2cw.pizzaapp.controller.Usercontroller;
import com.ead2cw.pizzaapp.repository.Userrepository;
import com.ead2cw.pizzaapp.service.Userinterface;
import com.ead2cw.pizzaapp.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Userservice implements Userinterface{

     private String name = "dinesha";

     private String password = "123";

     public String message;

     @Autowired
     private Userrepository userrepository;

     @Override
    public String saveUser(User user){
         System.out.println(user);

         User user1 = new User();
         user1 = user;

         System.out.println("User name :" +user1.getUsername());
         System.out.println("password :" +user1.getPassword());
         userrepository.save(user);

         return "user added";
     }

     public String login(String name, String password) {
         if (name.equals(name) && password.equals(password)) {
             message = "pass";
         } else {
             message = "fail";
         }
       return message;
     }
}
