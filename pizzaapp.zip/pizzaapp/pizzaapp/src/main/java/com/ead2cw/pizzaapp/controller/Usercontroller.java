package com.ead2cw.pizzaapp.controller;


import com.ead2cw.pizzaapp.model.User;
import com.ead2cw.pizzaapp.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class Usercontroller {


    @Autowired
    private Userservice userservice;

    @RequestMapping("/")
    public String login(){
        return "login";
    }

     @PostMapping("/login")
    public String login(@ModelAttribute User user){
        String message;
        if(userservice.login(user.getUsername(),user.getPassword()).equals("pass")){
            message = "successful!";
        }else{
            message = "Fail!";
        }
        return message;
     }
}
