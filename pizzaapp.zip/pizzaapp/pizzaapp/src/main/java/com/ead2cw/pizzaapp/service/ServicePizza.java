package com.ead2cw.pizzaapp.service;

import com.ead2cw.pizzaapp.model.pizza;
import com.ead2cw.pizzaapp.repository.pizzaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicePizza implements pizzaService{

    @Autowired
    private pizzaRepository pizzaRepository;

    @Override
    public pizza savepizzaUser(pizza pizza) {
        return pizzaRepository.save(pizza);
    }

    @Override
    public List<pizza> getAllUsers() {
        return pizzaRepository.findAll();
    }

   @Override
    public void deleteProduct(int id){
        pizzaRepository.deleteById(id);
   }
}
