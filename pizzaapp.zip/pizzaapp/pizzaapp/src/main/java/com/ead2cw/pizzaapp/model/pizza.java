package com.ead2cw.pizzaapp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class pizza {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String proname;
    private String prosize;

    private int Price;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public String getProsize() {
        return prosize;
    }

    public void setProsize(String prosize) {
        this.prosize = prosize;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }
}
