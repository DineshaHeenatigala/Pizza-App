package com.ead2cw.pizzaapp.controller;


import com.ead2cw.pizzaapp.model.cart;
import com.ead2cw.pizzaapp.model.cartproduct;
import com.ead2cw.pizzaapp.service.cartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
@CrossOrigin
public class Cartcontroller {

    public String message;
    @Autowired
    private com.ead2cw.pizzaapp.service.cartService cartService;

    private com.ead2cw.pizzaapp.model.cart cart = new cart();

    @PostMapping("/add")
    public String add(@RequestBody cartproduct cartproduct){
        cartService.savecartproduct(cartproduct);
        return "added your cart!";
    }
    @PostMapping("/addToCart")
    public String addToCart(int id){
        message= cart.addToCart(id);
        return message;
    }

    @GetMapping("/deleteById")
    public String deleteById(int id){
        message = cart.deleteProduct(id);
       return message;
    }

    @PostMapping("/clearCart")
    public String clearCart(){
        cart.clear();
        cartService.clearCart();
        return "cleared the cart";
    }
}
