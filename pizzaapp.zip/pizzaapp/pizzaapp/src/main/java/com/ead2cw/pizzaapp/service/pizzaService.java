package com.ead2cw.pizzaapp.service;

import com.ead2cw.pizzaapp.model.pizza;

import java.util.List;

public interface pizzaService {
    public pizza savepizzaUser(pizza pizza);
    public List<pizza> getAllUsers();

    public void deleteProduct(int id);


}
