package com.ead2cw.pizzaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.ead2cw.pizzaapp")
public class PizzaappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PizzaappApplication.class, args);
	}

}
