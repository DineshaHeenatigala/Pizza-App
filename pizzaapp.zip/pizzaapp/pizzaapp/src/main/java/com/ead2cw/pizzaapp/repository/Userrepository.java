package com.ead2cw.pizzaapp.repository;


import com.ead2cw.pizzaapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Userrepository extends JpaRepository<User,Integer> {
}
